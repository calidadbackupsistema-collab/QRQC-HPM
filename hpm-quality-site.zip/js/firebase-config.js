/* ============================================================
   HPM · Configuración de Firebase
   ------------------------------------------------------------
   1. Firebase Console → Configuración del proyecto → "Tus apps" → Web (</>)
   2. Copia el objeto firebaseConfig y pega sus valores aquí.
   Estos valores son PÚBLICOS por diseño (identifican el proyecto);
   la seguridad la dan Authentication + firestore.rules.
   Mientras apiKey siga como "TU_API_KEY" las apps trabajan en MODO LOCAL
   (datos solo en este navegador, sin inicio de sesión).
   ============================================================ */
window.HPM_FIREBASE_CONFIG = {
  apiKey: "TU_API_KEY",
  authDomain: "TU_PROYECTO.firebaseapp.com",
  projectId: "TU_PROYECTO",
  storageBucket: "TU_PROYECTO.appspot.com",
  messagingSenderId: "000000000000",
  appId: "1:000000000000:web:0000000000000000"
};
