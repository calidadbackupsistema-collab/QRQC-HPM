/* ============================================================
   HPM · Capa de datos  (localStorage  <->  Firebase Firestore)
   - Las apps siguen usando localStorage; esta capa lo replica en Firestore.
   - Sin configuración de Firebase => modo local (todo funciona igual).
   - Con Firebase: inicio de sesión, sincronización por registro y en vivo.
   Expone window.HPMSync = { enabled, ready, status, user, onRemote(fn), signOut() }
   ============================================================ */
(function () {
  'use strict';
  var KEYS = ['quality_8d_reports_v1', 'hpm_9basics_reports_v1', 'hpm_2panel_reports_v1',
    'hpm_dmaic_reports_v1', 'hpm_doe_reports_v1', 'hpm_qrqcd_board_v1',
    'hpm_qrqcd_kpi_v1', 'hpm_qrqcd_meta_v1'];
  var OBJECT_KEYS = { hpm_qrqcd_kpi_v1: 1, hpm_qrqcd_meta_v1: 1 };      // se guardan como 1 documento
  var MAX_DOC = 900 * 1024;                                              // límite Firestore = 1 MiB
  var FB_VER = '10.14.1';
  var cfg = window.HPM_FIREBASE_CONFIG || {};
  var enabled = !!(cfg.apiKey && !/^TU_|YOUR_/i.test(cfg.apiKey) && cfg.projectId && !/^TU_|YOUR_/i.test(cfg.projectId));

  var listeners = [], statusListeners = [];
  var api = { enabled: enabled, status: enabled ? 'connecting' : 'local', userEmail: '', ready: null, KEYS: KEYS,
    onRemote: function (fn) { listeners.push(fn); },
    onStatus: function (fn) { statusListeners.push(fn); },
    maxFileBytes: enabled ? 700 * 1024 : 4 * 1024 * 1024 };
  window.HPMSync = api;
  function setStatus(s, extra) { api.status = s; statusListeners.forEach(function (f) { try { f(s, extra); } catch (e) {} }); }

  /* ---------- Utilidades locales ---------- */
  var nativeSet = Storage.prototype.setItem, nativeRemove = Storage.prototype.removeItem;
  var suppress = false;
  function readLocal(key) { try { return JSON.parse(localStorage.getItem(key) || 'null'); } catch (e) { return null; } }
  function writeLocalSilently(key, value) { suppress = true; try { nativeSet.call(localStorage, key, JSON.stringify(value)); } finally { suppress = false; } }
  function toMap(key, value) {            // valor local -> { docId: jsonString }
    var m = {};
    if (OBJECT_KEYS[key]) { if (value && typeof value === 'object' && !Array.isArray(value)) m._obj = JSON.stringify(value); }
    else if (Array.isArray(value)) value.forEach(function (it) { if (it && it.id != null) m[String(it.id)] = JSON.stringify(it); });
    return m;
  }
  function fromMap(key, m) {
    if (OBJECT_KEYS[key]) return m._obj ? JSON.parse(m._obj) : null;
    return Object.keys(m).map(function (k) { return JSON.parse(m[k]); }).sort(function (a, b) { return Number(b.id) - Number(a.id); });
  }
  function sameMap(a, b) {
    var ka = Object.keys(a), kb = Object.keys(b);
    if (ka.length !== kb.length) return false;
    return ka.every(function (k) { return a[k] === b[k]; });
  }

  if (!enabled) { api.ready = Promise.resolve(); return; }

  /* ---------- Modo Firebase ---------- */
  var T = { es: { title: 'Acceso al sistema de calidad', email: 'Correo', pass: 'Contraseña', login: 'Entrar', google: 'Entrar con Google',
      or: 'o', err: 'No se pudo iniciar sesión. Verifica tus datos.', denied: 'Tu correo no está autorizado. Solicita acceso al administrador de calidad.',
      out: 'Salir', sync: 'Sincronizado', saving: 'Guardando…', offline: 'Sin conexión (datos locales)', error: 'Error de sincronización' },
    en: { title: 'Quality system access', email: 'Email', pass: 'Password', login: 'Sign in', google: 'Sign in with Google', or: 'or',
      err: 'Sign-in failed. Check your details.', denied: 'Your email is not authorized. Ask the quality administrator for access.',
      out: 'Sign out', sync: 'Synced', saving: 'Saving…', offline: 'Offline (local data)', error: 'Sync error' },
    ko: { title: '품질 시스템 로그인', email: '이메일', pass: '비밀번호', login: '로그인', google: 'Google로 로그인', or: '또는',
      err: '로그인에 실패했습니다.', denied: '승인되지 않은 이메일입니다. 품질 관리자에게 문의하세요.', out: '로그아웃',
      sync: '동기화됨', saving: '저장 중…', offline: '오프라인 (로컬 데이터)', error: '동기화 오류' } };
  function tx(k) { var l = localStorage.getItem('hpm_lang') || 'es'; return (T[l] || T.es)[k] || T.es[k]; }

  var fb = {}, db, auth, lastRemote = {}, pushTimers = {}, firstDone = {};

  function injectCss() {
    var s = document.createElement('style');
    s.textContent = '#hpmLogin{position:fixed;inset:0;z-index:9999;display:grid;place-items:center;padding:20px;background:radial-gradient(circle at 20% 15%,#14507f,#06182a 70%);font-family:"IBM Plex Sans",system-ui,sans-serif}' +
      '#hpmLogin form{width:min(380px,100%);background:#fff;border-radius:18px;padding:28px 26px;box-shadow:0 30px 80px #0008}' +
      '#hpmLogin img{height:44px;display:block;margin:0 auto 14px}#hpmLogin h2{margin:0 0 16px;font-size:18px;text-align:center;color:#0B2D50}' +
      '#hpmLogin label{display:block;font:700 11px "IBM Plex Mono",monospace;color:#5A6C7E;margin:10px 0 4px;text-transform:uppercase}' +
      '#hpmLogin input{width:100%;padding:10px 12px;border:1px solid #D7E1EB;border-radius:9px;font-size:14px}' +
      '#hpmLogin button{width:100%;margin-top:14px;padding:11px;border:0;border-radius:10px;font-weight:700;font-size:14px;cursor:pointer;background:#0B2D50;color:#fff}' +
      '#hpmLogin button.g{background:#fff;color:#10263B;border:1px solid #C5D2DF}#hpmLogin .or{text-align:center;color:#8797A8;font-size:12px;margin-top:12px}' +
      '#hpmLogin .err{color:#C0182F;font-size:12.5px;margin-top:10px;min-height:16px;text-align:center}' +
      '#hpmChip{position:fixed;left:12px;bottom:12px;z-index:900;display:flex;gap:8px;align-items:center;background:#0B2D50ee;color:#fff;padding:6px 12px;border-radius:999px;font:600 11.5px "IBM Plex Sans",sans-serif;box-shadow:0 6px 20px #0004}' +
      '#hpmChip i{width:8px;height:8px;border-radius:50%;background:#4ADE80;display:inline-block}#hpmChip.saving i{background:#FFD26F}#hpmChip.error i,#hpmChip.offline i{background:#FF6B7F}' +
      '#hpmChip button{background:#ffffff22;color:#fff;border:0;border-radius:999px;padding:3px 10px;cursor:pointer;font:inherit}@media print{#hpmChip,#hpmLogin{display:none!important}}';
    document.head.appendChild(s);
  }

  function showLogin(message) {
    return new Promise(function (resolve) {
      var ov = document.getElementById('hpmLogin');
      if (!ov) {
        ov = document.createElement('div'); ov.id = 'hpmLogin';
        ov.innerHTML = '<form><img alt="HPM"><h2></h2><label></label><input type="email" id="hpmEm" autocomplete="username" required><label></label>' +
          '<input type="password" id="hpmPw" autocomplete="current-password" required><button type="submit" id="hpmGo"></button>' +
          '<div class="or"></div><button type="button" class="g" id="hpmG"></button><div class="err" id="hpmErr"></div></form>';
        document.body.appendChild(ov);
      }
      var logo = (typeof HPM_LOGO !== 'undefined') ? HPM_LOGO : ''; ov.querySelector('img').src = logo;
      var ls = ov.querySelectorAll('label');
      ov.querySelector('h2').textContent = tx('title'); ls[0].textContent = tx('email'); ls[1].textContent = tx('pass');
      document.getElementById('hpmGo').textContent = tx('login'); document.getElementById('hpmG').textContent = tx('google'); ov.querySelector('.or').textContent = tx('or');
      var err = document.getElementById('hpmErr'); err.textContent = message || '';
      ov.hidden = false;
      var form = ov.querySelector('form');
      form.onsubmit = function (e) {
        e.preventDefault(); err.textContent = '';
        fb.auth.signInWithEmailAndPassword(auth, document.getElementById('hpmEm').value.trim(), document.getElementById('hpmPw').value)
          .then(function () { resolve(); }).catch(function () { err.textContent = tx('err'); });
      };
      document.getElementById('hpmG').onclick = function () {
        err.textContent = '';
        fb.auth.signInWithPopup(auth, new fb.auth.GoogleAuthProvider()).then(function () { resolve(); }).catch(function () { err.textContent = tx('err'); });
      };
    });
  }

  function mountChip() {
    var c = document.getElementById('hpmChip'); if (!c) { c = document.createElement('div'); c.id = 'hpmChip'; document.body.appendChild(c); }
    function paint(s) {
      c.className = s === 'saving' ? 'saving' : (s === 'error' ? 'error' : (s === 'offline' ? 'offline' : ''));
      c.innerHTML = '<i></i><span>☁ ' + (api.userEmail || '') + ' · ' + tx(s === 'ok' ? 'sync' : s) + '</span><button type="button">' + tx('out') + '</button>';
      c.querySelector('button').onclick = function () { api.signOut(); };
    }
    paint('ok'); api.onStatus(paint);
  }

  api.signOut = function () { return fb.auth.signOut(auth).then(function () { location.reload(); }); };

  /* ---------- Empuje local -> Firestore ---------- */
  function schedulePush(key) {
    clearTimeout(pushTimers[key]); setStatus('saving');
    pushTimers[key] = setTimeout(function () { pushKey(key); }, 700);
  }
  function pushKey(key) {
    if (!db || !firstDone[key]) return Promise.resolve();
    var local = toMap(key, readLocal(key)), remote = lastRemote[key] || {};
    var batch = fb.fs.writeBatch(db), n = 0, skipped = 0;
    Object.keys(local).forEach(function (id) {
      if (remote[id] === local[id]) return;
      if (local[id].length > MAX_DOC) { skipped++; return; }
      batch.set(fb.fs.doc(db, key, id), { j: local[id], by: api.userEmail, ts: Date.now() }); n++;
    });
    Object.keys(remote).forEach(function (id) { if (!(id in local)) { batch.delete(fb.fs.doc(db, key, id)); n++; } });
    if (skipped) alert('Un registro supera 900 KB y no se sincronizó (reduce imágenes/archivos).');
    if (!n) { setStatus('ok'); return Promise.resolve(); }
    var snapshotLocal = {}; Object.keys(local).forEach(function (id) { if (local[id].length <= MAX_DOC) snapshotLocal[id] = local[id]; });
    return batch.commit().then(function () { lastRemote[key] = snapshotLocal; setStatus('ok'); })
      .catch(function (e) { console.error('HPM sync', e); setStatus('error'); });
  }

  Storage.prototype.setItem = function (k, v) {
    nativeSet.call(this, k, v);
    if (this === window.localStorage && !suppress && KEYS.indexOf(k) > -1) schedulePush(k);
  };
  Storage.prototype.removeItem = function (k) {
    nativeRemove.call(this, k);
    if (this === window.localStorage && !suppress && KEYS.indexOf(k) > -1) schedulePush(k);
  };

  /* ---------- Escucha Firestore -> local ---------- */
  function listen(key) {
    return new Promise(function (resolve) {
      var first = true;
      fb.fs.onSnapshot(fb.fs.collection(db, key), function (snap) {
        if (snap.metadata.hasPendingWrites && !first) return;           // eco de escritura local
        var remote = {}; snap.forEach(function (d) { var j = d.data().j; if (typeof j === 'string') remote[d.id] = j; });
        var local = toMap(key, readLocal(key));
        if (first) {
          first = false;
          var flag = 'hpm_sync_init_' + key;
          if (!localStorage.getItem(flag)) {                           // primera vez: fusionar local + nube
            var merged = Object.assign({}, local, remote);
            writeLocalSilently(key, fromMap(key, merged) || (OBJECT_KEYS[key] ? {} : []));
            suppress = true; try { nativeSet.call(localStorage, flag, '1'); } finally { suppress = false; }
            lastRemote[key] = remote; firstDone[key] = true; pushKey(key);
          } else {                                                       // la nube manda
            if (!sameMap(local, remote)) writeLocalSilently(key, fromMap(key, remote) || (OBJECT_KEYS[key] ? {} : []));
            lastRemote[key] = remote; firstDone[key] = true;
          }
          resolve(); return;
        }
        lastRemote[key] = remote;
        if (sameMap(local, remote)) return;
        writeLocalSilently(key, fromMap(key, remote) || (OBJECT_KEYS[key] ? {} : []));
        listeners.forEach(function (f) { try { f(key); } catch (e) { console.error(e); } });
      }, function (e) {
        console.error('HPM listen', key, e);
        if (e && e.code === 'permission-denied') { setStatus('error'); }
        firstDone[key] = true; resolve();
      });
    });
  }

  /* ---------- Arranque ---------- */
  api.ready = (async function () {
    try {
      var base = 'https://www.gstatic.com/firebasejs/' + FB_VER + '/';
      var m = await Promise.all([import(base + 'firebase-app.js'), import(base + 'firebase-auth.js'), import(base + 'firebase-firestore.js')]);
      var app = m[0].initializeApp(cfg);
      fb.auth = m[1]; fb.fs = m[2]; auth = fb.auth.getAuth(app);
      db = fb.fs.initializeFirestore ? fb.fs.initializeFirestore(app, { localCache: fb.fs.persistentLocalCache ? fb.fs.persistentLocalCache() : undefined }) : fb.fs.getFirestore(app);
    } catch (e) { console.error('HPM Firebase no disponible, modo local', e); setStatus('offline'); return; }
    injectCss();
    var user = await new Promise(function (res) { var un = fb.auth.onAuthStateChanged(auth, function (u) { un(); res(u); }); });
    var msg = '';
    while (true) {
      if (!user) { await showLogin(msg); user = auth.currentUser; }
      api.userEmail = (user.email || '').toLowerCase();
      try {
        await fb.fs.getDoc(fb.fs.doc(db, 'hpm_allowed', api.userEmail));                      // prueba de acceso
        await fb.fs.getDocs(fb.fs.collection(db, KEYS[0]));
        break;
      } catch (e) {
        if (e && e.code === 'permission-denied') { await fb.auth.signOut(auth); user = null; msg = tx('denied'); continue; }
        setStatus('offline'); break;
      }
    }
    var ov = document.getElementById('hpmLogin'); if (ov) ov.hidden = true;
    mountChip();
    var timeout = new Promise(function (r) { setTimeout(r, 9000); });
    await Promise.race([Promise.all(KEYS.map(listen)), timeout]);
    KEYS.forEach(function (k) { if (!firstDone[k]) firstDone[k] = false; });
  })();
})();
